<?php

$jsonVerisi = file_get_contents("ogrenciler.json");
$ogrenciler = json_decode($jsonVerisi, true);

function harfNotuBul($not) {
    if ($not >= 90) {
        return ["AA", 4.00, "Başarılı"];
    } elseif ($not >= 85) {
        return ["BA", 3.50, "Başarılı"];
    } elseif ($not >= 80) {
        return ["BB", 3.00, "Başarılı"];
    } elseif ($not >= 75) {
        return ["CB", 2.50, "Başarılı"];
    } elseif ($not >= 70) {
        return ["CC", 2.00, "Başarılı"];
    } elseif ($not >= 60) {
        return ["DC", 1.50, "Geçer"];
    } elseif ($not >= 50) {
        return ["DD", 1.00, "Geçer"];
    } else {
        return ["FF", 0.00, "Kaldı"];
    }
}

$sonuclar = [];

foreach ($ogrenciler as $ogrenci) {
    $donemSonuNotu =
        $ogrenci["vize"] * 0.25 +
        $ogrenci["odev"] * 0.25 +
        $ogrenci["proje"] * 0.05 +
        $ogrenci["final"] * 0.45;

    list($harfNotu, $katsayi, $statu) = harfNotuBul($donemSonuNotu);

    $sonuclar[] = [
        "okul_no" => $ogrenci["okul_no"],
        "ad_soyad" => $ogrenci["ad_soyad"],
        "ders_adi" => $ogrenci["ders_adi"],
        "donem_sonu_notu" => number_format($donemSonuNotu, 2),
        "harf_notu" => $harfNotu,
        "katsayi" => number_format($katsayi, 2),
        "statu" => $statu
    ];
}

file_put_contents(
    "sonuclar.json",
    json_encode($sonuclar, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
);

?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Öğrenci Not Hesaplama</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f8;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.15);
        }

        th {
            background-color: #2c3e50;
            color: white;
            padding: 12px;
        }

        td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        .basarili {
            background-color: #d4edda;
            color: #155724;
        }

        .kaldi {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>

<h2>Öğrenci Not Hesaplama</h2>

<table>
    <tr>
        <th>Okul No</th>
        <th>Ad Soyad</th>
        <th>Ders Adı</th>
        <th>Vize</th>
        <th>Ödev</th>
        <th>Proje</th>
        <th>Final</th>
        <th>Dönem Sonu Notu</th>
        <th>Harf Notu</th>
        <th>Katsayı</th>
        <th>Statü</th>
    </tr>

    <?php foreach ($ogrenciler as $ogrenci): ?>

        <?php
        $donemSonuNotu =
            $ogrenci["vize"] * 0.25 +
            $ogrenci["odev"] * 0.25 +
            $ogrenci["proje"] * 0.05 +
            $ogrenci["final"] * 0.45;

        list($harfNotu, $katsayi, $statu) = harfNotuBul($donemSonuNotu);

        if ($donemSonuNotu < 50) {
            $satirRengi = "kaldi";
        } else {
            $satirRengi = "basarili";
        }
        ?>

        <tr class="<?php echo $satirRengi; ?>">
            <td><?php echo $ogrenci["okul_no"]; ?></td>
            <td><?php echo $ogrenci["ad_soyad"]; ?></td>
            <td><?php echo $ogrenci["ders_adi"]; ?></td>
            <td><?php echo $ogrenci["vize"]; ?></td>
            <td><?php echo $ogrenci["odev"]; ?></td>
            <td><?php echo $ogrenci["proje"]; ?></td>
            <td><?php echo $ogrenci["final"]; ?></td>
            <td><?php echo number_format($donemSonuNotu, 2); ?></td>
            <td><?php echo $harfNotu; ?></td>
            <td><?php echo number_format($katsayi, 2); ?></td>
            <td><?php echo $statu; ?></td>
        </tr>

    <?php endforeach; ?>

</table>

</body>
</html>