<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $urun_adi = htmlspecialchars($_POST['urun_adi'] ?? 'Bilinmeyen Ürün');
    
    $urun_fiyati = (float)($_POST['urun_fiyati'] ?? 0);
    $adet = (int)($_POST['adet'] ?? 0);
    $kdv_orani = (float)($_POST['kdv_orani'] ?? 0);
    $indirim_kodu = trim($_POST['indirim_kodu'] ?? '');

    $ara_toplam = $urun_fiyati * $adet;
    $kdv_tutari = $ara_toplam * ($kdv_orani / 100);

    $indirim_orani = 0;
    $indirim_mesaji = "İndirim uygulanmadı.";

    if ($indirim_kodu === "IND20") {
        $indirim_orani = 20;
        $indirim_mesaji = "“IND20” indirim kodu uygulanmıştır.";
    } elseif ($indirim_kodu === "IND50") {
        $indirim_orani = 50;
        $indirim_mesaji = "“IND50” indirim kodu uygulanmıştır.";
    }

    $indirim_tutari = $ara_toplam * ($indirim_orani / 100);
    
    $genel_toplam = $ara_toplam + $kdv_tutari - $indirim_tutari;

    echo "<h2>$urun_adi için toplam tutar: $genel_toplam TL</h2>";
    echo "Birim Fiyat: $urun_fiyati TL <br>";
    echo "Adet: $adet <br><br>";
    echo "Ara Toplam: $ara_toplam TL <br>";
    echo "KDV Tutarı: $kdv_tutari TL <br>";
    
    if ($indirim_orani > 0) {
        echo "$indirim_mesaji ve İndirim Tutarı: $indirim_tutari TL <br>";
    }

    echo "<h3>Genel Toplam: $genel_toplam TL</h3>";
} else {
    echo "Lütfen formu kullanarak giriş yapın.";
}
?>