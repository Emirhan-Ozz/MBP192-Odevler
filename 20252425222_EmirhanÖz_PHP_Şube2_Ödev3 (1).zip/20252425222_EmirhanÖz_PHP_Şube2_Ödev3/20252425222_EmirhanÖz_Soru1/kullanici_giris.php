<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kullanıcı Giriş</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php
$mesaj = "";
$mesajSinifi = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = trim($_POST['username']);
    $pass = trim($_POST['password']);

    if (empty($user) || empty($pass)) {
        $mesaj = "Lütfen tüm alanları doldurun";
        $mesajSinifi = "error";
    } else {
        if ($user === "admin" && $pass === "1234") {
            $mesaj = "Giriş başarılı, hoş geldiniz admin";
            $mesajSinifi = "success";
        } else {
            $mesaj = "Kullanıcı adı veya şifre hatalı";
            $mesajSinifi = "error";
        }
    }
}
?>

<?php if ($mesaj !== ""): ?>
    <div class="<?php echo $mesajSinifi; ?>"><?php echo $mesaj; ?></div>
<?php endif; ?>

<div class="login-box">
    <form action="" method="POST">
        Kullanıcı Adı: <input type="text" name="username">
        Şifre: <input type="password" name="password">
        <button type="submit">Giriş</button>
    </form>
</div>

</body>
</html>