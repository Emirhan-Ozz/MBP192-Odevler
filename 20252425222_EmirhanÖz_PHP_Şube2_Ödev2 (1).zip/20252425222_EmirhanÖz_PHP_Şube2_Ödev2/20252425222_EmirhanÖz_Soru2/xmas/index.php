<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xmas Countdown - Christmas Countdown Template</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="templatemo-605-xmas-countdown.css">
<!--

TemplateMo 605 Xmas Countdown

https://templatemo.com/tm-605-xmas-countdown

-->
</head>
<body>
    <?php
    $targetDate = "December 25, 2026 18:00:00"; 
    $displayDateText = "December 25, 2026 at 6:00 PM";

    $aboutTitle = "A Time for <span>Wonder</span> & Celebration";
    $aboutText1 = "Christmas is more than a holiday—it's a season of warmth, togetherness, and the simple joy of giving. As lights twinkle and snow falls, we're reminded of what truly matters.";
    $aboutText2 = "Whether gathering with loved ones or finding peace in quiet moments, this season invites us to pause, reflect, and celebrate the magic around us.";

    $event1_day = "15";
    $event1_month = "Dec";
    $event1_title = "Carol Night";
    $event1_desc = "An evening of classic Christmas carols performed by our community choir under the stars.";
    $event1_time = "7:00 PM";
    $event1_loc = "Town Square";

    $event2_day = "20";
    $event2_month = "Dec";
    $event2_title = "Cookie Exchange";
    $event2_desc = "Bring your favorite holiday treats and swap recipes with neighbors at our annual gathering.";
    $event2_time = "3:00 PM";
    $event2_loc = "Community Hall";

    $event3_day = "24";
    $event3_month = "Dec";
    $event3_title = "Candlelight Vigil";
    $event3_desc = "A peaceful Christmas Eve celebration with candlelight, reflection, and seasonal spirit.";
    $event3_time = "9:00 PM";
    $event3_loc = "City Chapel";

    $trad1_num = "01";
    $trad1_title = "Decorating the Tree";
    $trad1_desc = "Hanging ornaments collected over the years, each one telling its own story of Christmases past.";

    $trad2_num = "02";
    $trad2_title = "Secret Gift Exchange";
    $trad2_desc = "Finding the perfect gift for someone special, wrapped with love and anticipation.";

    $trad3_num = "03";
    $trad3_title = "Hot Cocoa Nights";
    $trad3_desc = "Gathering by the fire with warm mugs, sharing stories as snow falls softly outside.";

    $trad4_num = "04";
    $trad4_title = "Christmas Feast";
    $trad4_desc = "Gathering around the table with family for a special meal and cherished conversations.";
    ?>

    <!-- Background -->
    <div class="grid-bg"></div>
    <div class="particles" id="particles"></div>

    <!-- Header -->
    <header id="header">
        <a href="#hero" class="logo">
            <div class="logo-icon">🎄</div>
            <span class="logo-text">Xmas<span>Countdown</span></span>
        </a>
        <nav id="nav">
            <a href="#hero">Home</a>
            <a href="#about">About</a>
            <a href="#events">Events</a>
            <a href="#traditions">Traditions</a>
            <a href="#newsletter" class="nav-cta">Subscribe</a>
        </nav>
        <div class="nav-toggle" id="navToggle">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero" id="hero">
        <div class="hero-badge">
            <span class="dot"></span>
            Live Countdown Active
        </div>
        <h1>Christmas<br><span class="gradient">Countdown</span></h1>
        <p class="hero-subtitle">Every second brings us closer to the most magical celebration of the year</p>
        
        <div class="countdown-wrapper">
            <div class="countdown" id="countdown">
                <div class="countdown-item">
                    <span class="countdown-number" id="days">00</span>
                    <span class="countdown-label">Days</span>
                </div>
                <span class="countdown-colon">:</span>
                <div class="countdown-item">
                    <span class="countdown-number" id="hours">00</span>
                    <span class="countdown-label">Hours</span>
                </div>
                <span class="countdown-colon">:</span>
                <div class="countdown-item">
                    <span class="countdown-number" id="minutes">00</span>
                    <span class="countdown-label">Minutes</span>
                </div>
                <span class="countdown-colon">:</span>
                <div class="countdown-item">
                    <span class="countdown-number" id="seconds">00</span>
                    <span class="countdown-label">Seconds</span>
                </div>
            </div>

            <div class="target-date">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="16" y1="2" x2="16" y2="6"></line>
                    <line x1="8" y1="2" x2="8" y2="6"></line>
                    <line x1="3" y1="10" x2="21" y2="10"></line>
                </svg>
                <?php echo $displayDateText; ?>
            </div>
        </div>

        <div class="scroll-indicator">
            <span>Scroll</span>
            <div class="line"></div>
        </div>
    </section>

    <!-- About Section -->
    <section class="about" id="about">
        <div class="section-header">
            <span class="section-tag">About Us</span>
            <h2 class="section-title">The Spirit of Christmas</h2>
            <p class="section-subtitle">Celebrating traditions, creating memories, and spreading joy</p>
        </div>
        <div class="about-grid">
            <div class="about-image">
                <div class="about-image-stack">
                    <div class="about-img-item img-1">
                        <img src="images/christmas-pic-21.jpg" alt="Christmas Tree">
                    </div>
                    <div class="about-img-item img-2">
                        <img src="images/christmas-pic-22.jpg" alt="Christmas Lights">
                    </div>
                    <div class="about-img-item img-3">
                        <img src="images/christmas-pic-23.jpg" alt="Christmas Ornaments">
                    </div>
                </div>
            </div>
            <div class="about-content">
                <h3><?php echo $aboutTitle; ?></h3>
                <p><?php echo $aboutText1; ?></p>
                <p><?php echo $aboutText2; ?></p>
                <div class="about-features">
                    <div class="about-feature">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        Family Traditions
                    </div>
                    <div class="about-feature">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        Gift Giving
                    </div>
                    <div class="about-feature">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        Holiday Feasts
                    </div>
                    <div class="about-feature">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        Seasonal Music
                    </div>
                </div>
                <div class="about-templatemo">
                    <p>This free Christmas template is brought to you by <strong>TemplateMo</strong> — your destination for beautiful, modern website templates. Download hundreds of free HTML CSS templates for your personal and commercial projects.</p>
                    <a href="https://templatemo.com" target="_blank" class="btn-templatemo">
                        <span>Visit TemplateMo</span>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="7" y1="17" x2="17" y2="7"></line>
                            <polyline points="7 7 17 7 17 17"></polyline>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Events Section -->
    <section class="events" id="events">
        <div class="section-header">
            <span class="section-tag">Upcoming</span>
            <h2 class="section-title">Holiday Events</h2>
            <p class="section-subtitle">Mark your calendar for these special celebrations</p>
        </div>
        <div class="events-grid">
            <!-- Event 1 -->
            <div class="event-card">
                <div class="event-image">
                    <img src="images/christmas-pic-31.jpg" alt="Carol Night">
                    <div class="event-date-badge">
                        <div class="day"><?php echo $event1_day; ?></div>
                        <div class="month"><?php echo $event1_month; ?></div>
                    </div>
                </div>
                <div class="event-content">
                    <h3><?php echo $event1_title; ?></h3>
                    <p><?php echo $event1_desc; ?></p>
                    <div class="event-meta">
                        <span>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                            <?php echo $event1_time; ?>
                        </span>
                        <span>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                <circle cx="12" cy="10" r="3"></circle>
                            </svg>
                            <?php echo $event1_loc; ?>
                        </span>
                    </div>
                </div>
            </div>
            <!-- Event 2 -->
            <div class="event-card">
                <div class="event-image">
                    <img src="images/christmas-pic-32.jpg" alt="Cookie Exchange">
                    <div class="event-date-badge">
                        <div class="day"><?php echo $event2_day; ?></div>
                        <div class="month"><?php echo $event2_month; ?></div>
                    </div>
                </div>
                <div class="event-content">
                    <h3><?php echo $event2_title; ?></h3>
                    <p><?php echo $event2_desc; ?></p>
                    <div class="event-meta">
                        <span>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                            <?php echo $event2_time; ?>
                        </span>
                        <span>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                <circle cx="12" cy="10" r="3"></circle>
                            </svg>
                            <?php echo $event2_loc; ?>
                        </span>
                    </div>
                </div>
            </div>
            <!-- Event 3 -->
            <div class="event-card">
                <div class="event-image">
                    <img src="images/christmas-pic-33.jpg" alt="Candlelight Vigil">
                    <div class="event-date-badge">
                        <div class="day"><?php echo $event3_day; ?></div>
                        <div class="month"><?php echo $event3_month; ?></div>
                    </div>
                </div>
                <div class="event-content">
                    <h3><?php echo $event3_title; ?></h3>
                    <p><?php echo $event3_desc; ?></p>
                    <div class="event-meta">
                        <span>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                            <?php echo $event3_time; ?>
                        </span>
                        <span>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                <circle cx="12" cy="10" r="3"></circle>
                            </svg>
                            <?php echo $event3_loc; ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Traditions Section -->
    <section class="traditions" id="traditions">
        <div class="section-header">
            <span class="section-tag">Cherished</span>
            <h2 class="section-title">Holiday Traditions</h2>
            <p class="section-subtitle">The timeless rituals that make Christmas special</p>
        </div>
        <div class="traditions-grid">
            <!-- Tradition 1 -->
            <div class="tradition-card">
                <div class="tradition-image">
                    <img src="images/christmas-pic-41.jpg" alt="Decorating Tree">
                </div>
                <div class="tradition-content">
                    <div class="tradition-number"><?php echo $trad1_num; ?></div>
                    <h3><?php echo $trad1_title; ?></h3>
                    <p><?php echo $trad1_desc; ?></p>
                    <a href="#" class="tradition-btn">
                        <span>Learn More</span>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                </div>
            </div>
            <!-- Tradition 2 -->
            <div class="tradition-card">
                <div class="tradition-image">
                    <img src="images/christmas-pic-42.jpg" alt="Gift Exchange">
                </div>
                <div class="tradition-content">
                    <div class="tradition-number"><?php echo $trad2_num; ?></div>
                    <h3><?php echo $trad2_title; ?></h3>
                    <p><?php echo $trad2_desc; ?></p>
                    <a href="#" class="tradition-btn">
                        <span>Learn More</span>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                </div>
            </div>
            <!-- Tradition 3 -->
            <div class="tradition-card">
                <div class="tradition-image">
                    <img src="images/christmas-pic-43.jpg" alt="Hot Cocoa">
                </div>
                <div class="tradition-content">
                    <div class="tradition-number"><?php echo $trad3_num; ?></div>
                    <h3><?php echo $trad3_title; ?></h3>
                    <p><?php echo $trad3_desc; ?></p>
                    <a href="#" class="tradition-btn">
                        <span>Learn More</span>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                </div>
            </div>
            <!-- Tradition 4 -->
            <div class="tradition-card">
                <div class="tradition-image">
                    <img src="images/christmas-pic-44.jpg" alt="Christmas Feast">
                </div>
                <div class="tradition-content">
                    <div class="tradition-number"><?php echo $trad4_num; ?></div>
                    <h3><?php echo $trad4_title; ?></h3>
                    <p><?php echo $trad4_desc; ?></p>
                    <a href="#" class="tradition-btn">
                        <span>Learn More</span>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Newsletter Section -->
    <section class="newsletter" id="newsletter">
        <div class="newsletter-container">
            <div class="section-header" style="margin-bottom: 40px;">
                <span class="section-tag">Stay Updated</span>
                <h2 class="section-title">Join the Celebration</h2>
            </div>
            <p>Subscribe to receive holiday updates, event reminders, and a sprinkle of Christmas magic delivered to your inbox.</p>
            <form class="newsletter-form" id="newsletterForm">
                <input type="email" placeholder="Enter your email address" required>
                <button type="submit">Subscribe</button>
            </form>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="footer-grid">
            <div class="footer-brand">
                <a href="#hero" class="logo">
                    <div class="logo-icon">🎄</div>
                    <span class="logo-text">Xmas<span>Countdown</span></span>
                </a>
                <p>Celebrating the magic of Christmas with a live countdown, events, and traditions that bring us together.</p>
                <div class="footer-social">
                    <a href="#" title="Facebook">f</a>
                    <a href="#" title="Instagram">◎</a>
                    <a href="#" title="Twitter">𝕏</a>
                    <a href="#" title="YouTube">▶</a>
                </div>
            </div>
            <div class="footer-column">
                <h4>Navigation</h4>
                <ul>
                    <li><a href="#hero">Home</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#events">Events</a></li>
                    <li><a href="#traditions">Traditions</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h4>Resources</h4>
                <ul>
                    <li><a href="#">Gift Ideas</a></li>
                    <li><a href="#">Holiday Recipes</a></li>
                    <li><a href="#">Decoration Tips</a></li>
                    <li><a href="#">Event Planning</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h4>Contact</h4>
                <ul>
                    <li><a href="#">hello@christmas25.com</a></li>
                    <li><a href="#">Support</a></li>
                    <li><a href="#">FAQ</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2025 Xmas Countdown. Designed by <a rel="nofollow" href="https://templatemo.com" target="_blank">TemplateMo</a></p>
            <div class="footer-legal">
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Service</a>
            </div>
        </div>
    </footer>
</body>
</html>