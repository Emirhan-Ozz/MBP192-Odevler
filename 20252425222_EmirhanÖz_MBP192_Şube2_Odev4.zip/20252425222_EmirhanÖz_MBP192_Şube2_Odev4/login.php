<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>

<body class="login-body">

<div class="container">
    <h2>Giriş Yap</h2>

    <form method="POST">
        <input type="text" name="kullanici" placeholder="Kullanıcı Adı"><br>
        <input type="password" name="sifre" placeholder="Şifre"><br>
        <button type="submit">Giriş</button>
    </form>

    <?php
    if (isset($_POST["kullanici"]) && isset($_POST["sifre"])) {

        $kullanici = $_POST["kullanici"];
        $sifre = $_POST["sifre"];

        if ($kullanici == "admin" && $sifre == "123") {
            $_SESSION["kullanici"] = $kullanici;
            header("Location: panel.php");
            exit();
        } else {
            echo "<p class='error'>Hatalı giriş</p>";
        }
    }
    ?>
</div>

</body>
</html>