<?php
session_start();

if (!isset($_SESSION["kullanici"])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Panel</title>
    <link rel="stylesheet" href="style.css">
</head>

<body class="panel-body">

<div class="panel">
    <h2>Hoş geldin, <?php echo $_SESSION["kullanici"]; ?></h2>
    <a href="logout.php">Çıkış Yap</a>
</div>

</body>
</html>